﻿using Microsoft.ServiceBus.Messaging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace SendDataToEventHub
{
    class Program
    {

        const string eventHubName = "stormevents";

        // Copy the connection string ("Connection string-primary key") from your Event Hub namespace.
        const string connectionString = @"Endpoint=sb://iomegaeventhubnamespace.servicebus.windows.net/;SharedAccessKeyName=RootManageSharedAccessKey;SharedAccessKey=FW+gIPUo44yGcrUBNG8NQJfQibcFhwAIgQuLDbOG0t0=";

        static void Main(string[] args)
        {
            EventHubIngestion();
        }

        static void EventHubIngestion()
        {
            var eventHubClient = EventHubClient.CreateFromConnectionString(connectionString, eventHubName);

            List<StormEvent> StormEvents = JsonConvert.DeserializeObject<List<StormEvent>>(
                File.ReadAllText(@"StormEvents.json")
            );

            foreach (StormEvent se in StormEvents)
            {
                EventData eventData = new EventData(Encoding.UTF8.GetBytes(JsonConvert.SerializeObject(se)));
                Console.WriteLine($"sending message..." + "\n" + JsonConvert.SerializeObject(se));
                eventHubClient.Send(eventData);
            }


        }
    }
}
